import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileInputStream

// Функция для загрузки студентов из Excel файла
fun loadStudentGroupsFromExcel(filePath: String, groupNames: List<String>): Map<String, StudentGroup> {
    val groups = HashMap<String, StudentGroup>()
    FileInputStream(File(filePath)).use { fis ->
        val workbook = XSSFWorkbook(fis)
        for (groupName in groupNames) {
            val sheet = workbook.getSheet(groupName)
            val df = DataFormatter()

            val header = sheet.first()
            // Очень сложно определить количество не пустых клеток в строку, понадеемся, что их не больше ста
            val columnLimit = 100

            var firstAttendanceColumn = 0
            while (firstAttendanceColumn < columnLimit && header.getCell(firstAttendanceColumn).stringCellValue != "Гит") {
                firstAttendanceColumn++
            }
            // Посещаемость начинается сразу же после столбика с заголовком "Гит"
            firstAttendanceColumn++
            var firstLabColumn = firstAttendanceColumn
            while (firstLabColumn < columnLimit && header.getCell(firstLabColumn).cellType != CellType.STRING) {
                firstLabColumn++
            }

            var firstCourseWorkColumn = firstLabColumn
            while (firstCourseWorkColumn < columnLimit && header.getCell(firstCourseWorkColumn).stringCellValue.startsWith(
                    "ЛР"
                )
            ) {
                firstCourseWorkColumn++
            }

            var firstExamColumn = firstCourseWorkColumn
            while (firstExamColumn < columnLimit && header.getCell(firstExamColumn).stringCellValue.startsWith("ЭП")) {
                firstExamColumn++
            }

            // Скрытые колонки начинаются сразу же после контрольных работ
            var firstHiddenColumn = firstExamColumn
            while (firstHiddenColumn < columnLimit && header.getCell(firstHiddenColumn).stringCellValue.startsWith("КР")) {
                firstHiddenColumn++
            }

            // Делаем смелое предположение, что всё между контрольными работами и посещаемостью - это скрытая информация
            var firstSummariesColumn = firstHiddenColumn
            while (firstSummariesColumn < columnLimit) {
                val cell = header.getCell(firstSummariesColumn)
                if (cell.cellType == CellType.STRING && cell.stringCellValue == "Пос")
                    break

                firstSummariesColumn++
            }

            // БЛЯТЬ, ПОЧЕМУ У ВСЕХ ГРУПП ЕСТЬ ДВА СТОЛБИКА ПОС, А У 36/2 ТОЛЬКО ОДИН??????????
            if (header.getCell(firstSummariesColumn + 1).stringCellValue == "Пос")
                firstSummariesColumn++

            val totalColumn = firstSummariesColumn + 5
            val passColumn = firstSummariesColumn + 7

            val students = mutableListOf<Student>()
            for (row in sheet.drop(2)) {
                val idCell = row.getCell(0) ?: break
                val id = idCell.numericCellValue.toInt()
                val name = row.getCell(1).stringCellValue
                val attendance = (firstAttendanceColumn..<firstLabColumn).map {
                    df.formatCellValue(row.getCell(it)).replace("+", "1").toIntOrNull() ?: 0
                }
                val labWorks = (firstLabColumn..<firstCourseWorkColumn).map {
                    df.formatCellValue(row.getCell(it)).replace("д", "2").toIntOrNull() ?: 0
                }
                val courseWorks = (firstCourseWorkColumn..<firstExamColumn).map {
                    df.formatCellValue(row.getCell(it)).replace("д", "2").toIntOrNull() ?: 0
                }
                val exam = (firstExamColumn..<firstHiddenColumn).map {
                    df.formatCellValue(row.getCell(it)).replace("д", "2").toIntOrNull() ?: 0
                }
                val total = row.getCell(totalColumn).numericCellValue
                val pass = row.getCell(passColumn).stringCellValue != "недопуск"

                students.add(Student(id, name, attendance, labWorks, courseWorks, exam, total, pass))
            }

            groups[sheet.sheetName] = StudentGroup(students)
        }
    }
    return groups
}