import kotlinx.serialization.Serializable

// Определение класса для хранения информации о студенте
@Serializable
data class Student(
    val id: Int,
    val name: String,
    val attendance: List<Int>,
    val labWorks: List<Int>,
    val courseWorks: List<Int>,
    val exam: List<Int>,
    val total: Double,
    val pass: Boolean
)

@Serializable
data class StudentScore(
    val id: Int,
    val name: String,
    val attendance: Double,
    val lab: Double,
    val course: Double,
    val exam: Double,
    val total: Double
)

// Класс для обработки данных о студентах
@Serializable
class StudentGroup(val students: List<Student>) {
    fun getWorksAmongNonPass(works: (Student) -> List<Int>): Map<Int, Int> {
        val workCount = mutableMapOf<Int, Int>()
        students.filter { !it.pass }.forEach { student ->
            works(student).forEachIndexed { index, mark ->
                if (mark > 0) workCount[index + 1] = workCount.getOrDefault(index + 1, 0) + 1
            }
        }
        return workCount
    }

    // Метод для поиска лабораторной работы, выполненной наибольшим числом студентов, не получивших допуск
    fun mostSubmittedLabWorkAmongNonPass(): Int? {
        return getWorksAmongNonPass { student: Student -> student.labWorks }.maxByOrNull { it.value }?.key
    }

    // Метод для поиска экзаменационной работы, выполненной наименьшим числом студентов, не получивших допуск
    fun leastSubmittedCourseWorkAmongNonPass(): Int? {
        return getWorksAmongNonPass { student: Student -> student.courseWorks }.minByOrNull { it.value }?.key
    }

    // Метод для расчета баллов и их вывода для каждого студента
    fun calculateScores(): List<StudentScore> {
        return students.map { student ->
            val attendanceScore = student.attendance.count { it == 1 }.toDouble() / student.attendance.size * 100
            val labScore = student.labWorks.average()
            val courseScore = student.courseWorks.average()
            val examScore = student.exam.average()
            val totalScore = attendanceScore * 0.1 + labScore * 0.4 + courseScore * 0.3 + examScore * 0.2
            StudentScore(student.id, student.name, attendanceScore, labScore, courseScore, examScore, totalScore)
        }
    }

    // Метод для поиска пяти худших студентов среди получивших допуск
    fun worstFivePassStudents() = students.filter { it.pass }.sortedBy { it.total }.take(5)

    // Метод для поиска пяти лучших студентов среди не получивших допуск
    fun bestFiveNonPassStudents() = students.filter { !it.pass }.sortedByDescending { it.total }.take(5)

    // Метод для отображения данных группы в структурированном формате
    fun displayGroupData() {
        students.forEach { println(it) }
    }

    // Метод для поиска группы с наименьшим средним баллом среди тех, кто получил оценки 3, 4, или 5
    fun getLowestAveragePassScore(): Double {
        val passStudents = students.filter { it.pass && it.total >= 3 }
        return passStudents.map { it.total }.average()
    }
}