fun main() {
    val studentGroups = loadStudentGroupsFromExcel("FiLP.xlsx", listOf("36_1", "36_2", "39"))
    for (groupPair in studentGroups) {
        val groupName = groupPair.key
        val studentGroup = groupPair.value

        println("------------ ГРУППА $groupName ------------")
        println()

        // Поиск лабораторной работы, выполненной наибольшим числом студентов, не получивших допуск
        val mostSubmittedLab =
            studentGroup.mostSubmittedLabWorkAmongNonPass()?.toString() ?: "никто не выполнил ни одной работы"
        println("Лабораторная работа с наибольшим количеством выполнений среди недопущенных студентов: $mostSubmittedLab")

        // Поиск аттестационной работы, выполненной наименьшим числом студентов, не получивших допуск
        val leastSubmittedCourse =
            studentGroup.leastSubmittedCourseWorkAmongNonPass()?.toString() ?: "никто не выполнил ни одной работы"
        println("Экзаменационная работа с наименьшим количеством выполнений среди недопущенных студентов: $leastSubmittedCourse")

        // Расчет баллов для каждого студента
        studentGroup.calculateScores().forEach { score ->
            println("${score.name}: Посещаемость = ${score.attendance}, Лабораторные = ${score.lab}, Курсовые = ${score.course}, Экзамен = ${score.exam}, Итого = ${score.total}")
        }

        // Поиск пяти худших студентов среди получивших допуск
        studentGroup.worstFivePassStudents()
            .forEach { println("Худший среди допущенных: ${it.name}, Итого: ${it.total}") }

        // Поиск пяти лучших студентов среди не получивших допуск
        studentGroup.bestFiveNonPassStudents()
            .forEach { println("Лучший среди недопущенных: ${it.name}, Итого: ${it.total}") }

        // Отображение данных группы в структурированном формате
        studentGroup.displayGroupData()
    }

    val groupScores: List<Pair<String, Double>> =
        studentGroups.map { Pair(it.key, it.value.getLowestAveragePassScore()) }
            .sortedBy { it.second }
    println("Список групп по наименьшиму среднему баллу среди допущенных студентов:")
    groupScores.forEachIndexed { index, pair -> println("${index + 1}. ${pair.first} (${pair.second})") }

    // Запуск сервера
    startServer()
}
