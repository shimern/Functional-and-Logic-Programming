import io.ktor.server.application.*
import io.ktor.http.*
import io.ktor.serialization.gson.*
import io.ktor.server.application.hooks.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.util.*

fun Application.module() {
    install(ContentNegotiation) {
        gson {
            setPrettyPrinting()
        }
    }

    val groups = loadStudentGroupsFromExcel("FiLP.xlsx", listOf("36_1", "36_2", "39"))

    routing {
        // Получить список групп, отсортированный по возрастанию среднего балла среди допущенных студентов
        get("/top-lowest-score") {
            val groupScores: List<Pair<String, Double>> =
                groups.map { Pair(it.key, it.value.getLowestAveragePassScore()) }
                    .sortedBy { it.second }

            call.respond(groupScores)
        }

        // Вложенный роутер для всех запросов, связанных с группой студентов
        route("/group/{name}") {
            val groupAttribute = AttributeKey<StudentGroup>("group")
            // Плагин, предотвращающий выполнение, если группа с названием {name} не найдена
            install(createRouteScopedPlugin("groupPlugin") {
                on(CallSetup) { call ->
                    val groupName = call.parameters["name"]

                    if (groupName == null)
                        call.respond(HttpStatusCode.BadRequest)

                    val group = groups[groupName]
                    if (group == null)
                        call.respond(HttpStatusCode.NotFound)

                    call.attributes.put(groupAttribute, group!!)
                }
            })

            // Получить список всех студентов
            get {
                call.respond(call.attributes[groupAttribute])
            }

            // Получить наиболее часто выполненную лабораторную работу среди аттестованных.
            // Возвращает -1, если НИКТО не выполнил ни одной работы.
            get("/most-submitted-lab") {
                call.respond(call.attributes[groupAttribute].mostSubmittedLabWorkAmongNonPass() ?: -1)
            }

            // Получить наименее часто выполненную аттестационную работу среди аттестованных.
            // Возвращает -1, если НИКТО не выполнил ни одной работы.
            get("/least-submitted-course-work") {
                call.respond(call.attributes[groupAttribute].leastSubmittedCourseWorkAmongNonPass() ?: -1)
            }

            // Получить баллы всех студентов
            get("/scores") {
                call.respond(call.attributes[groupAttribute].calculateScores())
            }

            // Получить ТОП-5 худших аттестованных студентов
            get("/worst-five-students-pass") {
                call.respond(call.attributes[groupAttribute].worstFivePassStudents())
            }

            // Получить ТОП-5 лучших неаттестованных студентов
            get("/best-five-students-non-pass") {
                call.respond(call.attributes[groupAttribute].bestFiveNonPassStudents())
            }
        }
    }
}

fun startServer() {
    embeddedServer(Netty, port = 8080, module = Application::module).start(wait = true)
}